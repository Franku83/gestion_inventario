from django.apps import AppConfig


class TipologiaConfig(AppConfig):
    name = 'tipologia'
