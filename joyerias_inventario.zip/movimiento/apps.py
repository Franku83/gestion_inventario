from django.apps import AppConfig


class MovimientoConfig(AppConfig):
    name = 'movimiento'
